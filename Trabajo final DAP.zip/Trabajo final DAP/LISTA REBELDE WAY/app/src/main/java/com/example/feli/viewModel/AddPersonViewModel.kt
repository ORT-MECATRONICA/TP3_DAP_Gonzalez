package com.example.feli.viewModel

import androidx.lifecycle.ViewModel

class AddPersonViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}