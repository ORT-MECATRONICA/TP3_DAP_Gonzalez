package com.example.feli.viewModel

import androidx.lifecycle.ViewModel

class RecyclerViewViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}