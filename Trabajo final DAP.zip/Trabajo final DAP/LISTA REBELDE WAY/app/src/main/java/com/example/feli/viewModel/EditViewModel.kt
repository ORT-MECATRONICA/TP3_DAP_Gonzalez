package com.example.feli.viewModel

import androidx.lifecycle.ViewModel

class EditViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}