package com.example.feli.viewModel

import androidx.lifecycle.ViewModel

class FeliInfoViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}